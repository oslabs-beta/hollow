/**
 * @description typescript models for sidebar
 */

 export interface FieldViewProps {
  activeEntry: object;
  activeItem: string;
  newEntry: boolean;
  collectionEntries: string[][];
 }