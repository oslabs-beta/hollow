/**
 * @description typescript models for Header
 */


interface Props {
    text: string;
}